<?php
require '../sdk/ApiSdk.php';
$sdk = new ApiSdk(); 
$token = getAdminToken();

// First API call
$a = $sdk->getAllUsers(null);
$numUsers = $a['TotalRecords'];
$username = 'user'.$numUsers.'@arcadier.com';
$data = [
   'Email' => $username,
   'Password' => $username,
   'ConfirmPassword' => $username
];

// Second API call
$b = $sdk->registerUser($data);
$userID = $b['UserId'];
// Third API call
$c = $sdk->upgradeUserRole($userID, 'merchant');
echo ($c);
?>
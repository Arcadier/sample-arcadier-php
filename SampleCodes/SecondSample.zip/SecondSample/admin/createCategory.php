<?php
require '../sdk/ApiSdk.php';
$sdk = new ApiSdk(); 
$token = getAdminToken();

// First API call
$a = $sdk->getCategories(null);
$numCategories = $a['TotalRecords'];
$name = 'category'.$numCategories;
$data = [
   'Name' => $name,
   'Description' => $name
];

// Second API call
$b = $sdk->createCategory($data);
echo json_encode($b);
?>